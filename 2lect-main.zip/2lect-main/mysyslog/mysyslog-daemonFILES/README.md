cat /var/log/mysyslog.log
nano /etc/systemd/system/mysyslog-daemon.service
