# MySyslog

This repository contains a logging system implemented in C.
It includes:
- A core library for logging (libmysyslog)
- Plugins for different formats (libmysyslog-text and libmysyslog-json)
- A client application (mysyslog-client)
- A daemon application (mysyslog-daemon)
